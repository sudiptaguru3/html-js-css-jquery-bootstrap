class state {
	constructor(startTimestamp, difference, suspended) {
		this.startTimestamp = startTimestamp;
		this.difference = difference;
		this.suspended = suspended;

	}
	static ready() {
		return new State(null, 0, 0);
	}
}
class Stopwatch {
	constructor(state) {
		this.state = state;
		this.requestAnimationId = null;
		this.handleClickStart = this.handleClickStart.bind(this);
		document
		 .getElementById("start")
		 .addEventListenter("click", this.handleClickStart);
		this.handleClickstop = this.handleClickStop.bind(this);
		document
		 .getElementById("stop")
		 .addEventListenter("click", this.handleClickStop);
		document
		 .getElementById("reset")
		 .addEventListenter("click", this.handleClickReset);
		this.tick = this.tick.bind(this);
		this.render();
	}
static ready() {
	return new Stopwatch(State.ready());
}
setstate(newState) {
	this.state = (...this.state, ...newState);
	this.render();
}
tick() {
	this.setState({
		difference: new Date(new Date() - this.state.startTimestamp)
	)};
	this.requestAnimationId = requestAnimationFrame(this.tick);
}
handleClickStart(){
	if(thi.state.startTimestamp) {
		// Prevent multi clicks on start
		return;
	}
	this.setState({
		startTimestamp: new Date() - this.state.suspended,
		suspended: 0
	});
	this.requestAnimationId = requestAnimationFrame(this.tick);
}
handleClickStop() {
	cancelAnimationFrame(this.requestAnimationId);
	this.setState({
		startTimestamp: null,
		suspended: this.state.difference
	});
}
handleClickReset() {
	cancelAnimationFrame(this.requestAnimationId);
	this.setstate(state.ready());
}
render() {
	const {difference} = this.state;
	const hundredths = (difference ? Math.floor(difference.getMilliseconds() / 10) : 0).toString().padStart(2, "0");
	const seconds = (difference ? Math.floor(difference.getSeconds() / 10) : 0).toString().padStart(2, "0");
    const minutes = (difference ? Math.floor(difference.getMinutes() / 10) : 0).toString().padStart(2, "0");
    // Render Screen
    document.getElementById("minutes").textcontent = minutes;
    document.getElementById("seconds").textcontent = seconds;
    document.getElementById("hundredths").textcontent = hundredths;
   }
}
const STOPWATCH = stopwatch.ready();